package com.example.mywatertracker

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.Manifest
import android.util.Log

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                Log.d(TAG, "Notification permission granted.")
                startWaterTrackerService()
            } else {
                Log.w(TAG, "Notification permission denied. Service cannot start.")
                Toast.makeText(this, "Notification permission denied. The water tracker service cannot start.", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ensurePermissionAndStartService()

        findViewById<Button>(R.id.drinkWaterButton)?.setOnClickListener {
            val serviceIntent = Intent(this, WaterTrackerService::class.java).apply {
                action = "ACTION_DRINK_WATER"
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            Toast.makeText(this, "Drank 250ml of water!", Toast.LENGTH_SHORT).show()
        }
    }


    private fun ensurePermissionAndStartService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startWaterTrackerService()
        }
    }

    private fun startWaterTrackerService() {
        Log.d(TAG, "Attempting to start WaterTrackerService.")
        val serviceIntent = Intent(this, WaterTrackerService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
    }
}
