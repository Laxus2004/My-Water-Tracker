package com.example.mywatertracker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import android.os.Build.VERSION_CODES

class WaterTrackerService : Service() {

    private val NOTIFICATION_ID = 101
    private val CHANNEL_ID = "WATER_TRACKER_CHANNEL"
    private val TAG = "WaterTrackerService"
    private val WATER_LOSS_ML_PER_HOUR = 50


    private lateinit var serviceHandler: Handler
    private var currentFluidBalanceMl = 2000

    private val waterLossRunnable = object : Runnable {
        override fun run() {
            currentFluidBalanceMl -= WATER_LOSS_ML_PER_HOUR
            Log.d(TAG, "Fluid Balance: $currentFluidBalanceMl ml")
            updateNotification("Current Balance: ${currentFluidBalanceMl} ml")

            serviceHandler.postDelayed(this, 3000L)
        }
    }


    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service Created - Initializing Handler and Foreground.")

        val handlerThread = HandlerThread(TAG).apply { start() }
        serviceHandler = Handler(handlerThread.looper)

        startForeground(NOTIFICATION_ID, createNotification("Tracker Running...").build())

        serviceHandler.post(waterLossRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Service started with command")

        when (intent?.action) {
            "ACTION_DRINK_WATER" -> {
                drinkWater(250)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceHandler.removeCallbacks(waterLossRunnable)
        Log.d(TAG, "Service Destroyed")
    }


    private fun drinkWater(amountMl: Int) {
        serviceHandler.post {
            currentFluidBalanceMl += amountMl
            updateNotification("Water Drank: +${amountMl}ml. New Balance: ${currentFluidBalanceMl} ml")
        }
    }

    private fun createNotification(contentText: String): NotificationCompat.Builder {
        createNotificationChannel()

        val notificationIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent: PendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val drinkIntent = Intent(this, WaterTrackerService::class.java).apply {
            action = "ACTION_DRINK_WATER"
        }
        val drinkPendingIntent: PendingIntent = PendingIntent.getService(
            this, 0, drinkIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        val drinkAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_edit,
            "Drank Water", drinkPendingIntent
        ).build()


        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Water Tracker Active")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .addAction(drinkAction)
    }

    private fun updateNotification(text: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = createNotification(text).build()
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Water Tracker Notifications"
            val descriptionText = "Continuous fluid balance updates"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
